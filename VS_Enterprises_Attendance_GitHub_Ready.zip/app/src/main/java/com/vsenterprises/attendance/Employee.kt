package com.vsenterprises.attendance

data class Employee(
    val name: String = "",
    val employeeId: String = "",
    val mobile: String = "",
    val isAdmin: Boolean = false,
    val sharing: Boolean = false,
    val liveLat: Double? = null,
    val liveLng: Double? = null
)
