package com.vsenterprises.attendance

data class AttendanceRecord(
    val id: String = "",
    val uid: String = "",
    val employeeName: String = "",
    val type: String = "",
    val timestamp: Long = 0L,
    val dutyDurationHours: Int = 0
)
