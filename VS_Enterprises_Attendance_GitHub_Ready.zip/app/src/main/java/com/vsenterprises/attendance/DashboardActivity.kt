package com.vsenterprises.attendance

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Date

class DashboardActivity : AppCompatActivity() {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private lateinit var prefs: android.content.SharedPreferences

    private lateinit var greeting: TextView
    private lateinit var empIdText: TextView
    private lateinit var dutySpinner: Spinner
    private lateinit var statusCard: TextView
    private lateinit var checkButton: Button
    private lateinit var mapButton: Button

    private var employeeName = ""
    private var isAdmin = false

    private val locationPermissionRequestCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        prefs = getSharedPreferences("duty", MODE_PRIVATE)

        greeting = findViewById(R.id.greeting)
        empIdText = findViewById(R.id.empIdText)
        dutySpinner = findViewById(R.id.dutySpinner)
        statusCard = findViewById(R.id.statusCard)
        checkButton = findViewById(R.id.checkButton)
        mapButton = findViewById(R.id.mapButton)

        val adapter = ArrayAdapter.createFromResource(this, R.array.duty_options, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dutySpinner.adapter = adapter

        checkButton.setOnClickListener { onCheckButtonClicked() }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        mapButton.setOnClickListener {
            startActivity(Intent(this, TeamMapActivity::class.java))
        }
        findViewById<TextView>(R.id.logout).setOnClickListener {
            stopService(Intent(this, LocationService::class.java))
            auth.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finishAffinity()
        }

        loadEmployee()
        refreshDutyState()
    }

    override fun onResume() {
        super.onResume()
        refreshDutyState()
    }

    private fun loadEmployee() {
        val user = auth.currentUser ?: return
        db.collection("employees").document(user.uid).get().addOnSuccessListener { doc ->
            employeeName = doc.getString("name") ?: "Employee"
            isAdmin = doc.getBoolean("isAdmin") ?: false
            greeting.text = "Hello, $employeeName"
            empIdText.text = "Employee ID: ${doc.getString("employeeId") ?: "-"}"
            mapButton.visibility = if (isAdmin) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun refreshDutyState() {
        val endAt = prefs.getLong("endAt", 0L)
        val checkedIn = endAt > System.currentTimeMillis()
        if (checkedIn) {
            val time = DateFormat.format("hh:mm a", Date(endAt))
            statusCard.text = "Checked in. Sharing location until $time"
            checkButton.text = "CHECK OUT"
            dutySpinner.isEnabled = false
        } else {
            statusCard.text = "Not checked in"
            checkButton.text = "CHECK IN"
            dutySpinner.isEnabled = true
        }
    }

    private fun onCheckButtonClicked() {
        val currentlyCheckedIn = prefs.getLong("endAt", 0L) > System.currentTimeMillis()
        if (currentlyCheckedIn) {
            checkOut()
        } else {
            if (hasLocationPermissions()) {
                checkIn()
            } else {
                requestLocationPermissions()
            }
        }
    }

    private fun hasLocationPermissions(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val notif = if (Build.VERSION.SDK_INT >= 33)
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else true
        return fine && notif
    }

    private fun requestLocationPermissions() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), locationPermissionRequestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionRequestCode) {
            if (hasLocationPermissions()) {
                checkIn()
            } else {
                Toast.makeText(this, "Location permission is required to check in.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun checkIn() {
        val hours = if (dutySpinner.selectedItemPosition == 1) 12 else 8
        val endAt = System.currentTimeMillis() + hours * 60 * 60 * 1000L
        prefs.edit().putLong("endAt", endAt).apply()

        val intent = Intent(this, LocationService::class.java)
        intent.putExtra("endAt", endAt)
        ContextCompat.startForegroundService(this, intent)

        writeAttendance("checkin", hours)
        refreshDutyState()
    }

    private fun checkOut() {
        stopService(Intent(this, LocationService::class.java))
        prefs.edit().putLong("endAt", 0L).apply()
        val user = auth.currentUser
        if (user != null) {
            db.collection("employees").document(user.uid)
                .update("sharing", false)
        }
        writeAttendance("checkout", 0)
        refreshDutyState()
    }

    private fun writeAttendance(type: String, hours: Int) {
        val user = auth.currentUser ?: return
        val record = hashMapOf(
            "uid" to user.uid,
            "employeeName" to employeeName,
            "type" to type,
            "timestamp" to com.google.firebase.Timestamp.now(),
            "dutyDurationHours" to hours
        )
        db.collection("attendance").add(record)
    }
}
