package com.vsenterprises.attendance

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class LoginActivity : AppCompatActivity() {

    private lateinit var phoneField: EditText
    private lateinit var sendOtp: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        phoneField = findViewById(R.id.phone)
        sendOtp = findViewById(R.id.sendOtp)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        sendOtp.setOnClickListener { attemptSendOtp() }
    }

    private fun attemptSendOtp() {
        val mobile = phoneField.text?.toString()?.trim().orEmpty()
        if (mobile.length != 10) {
            status.text = "Please enter a valid 10-digit mobile number."
            return
        }
        val fullNumber = "+91$mobile"
        setLoading(true)

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(fullNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    signInWithCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    setLoading(false)
                    status.text = "Failed: ${e.message}"
                }

                override fun onCodeSent(verificationId: String, token: PhoneAuthProvider.ForceResendingToken) {
                    setLoading(false)
                    val intent = Intent(this@LoginActivity, OtpActivity::class.java)
                    intent.putExtra("verificationId", verificationId)
                    intent.putExtra("phone", fullNumber)
                    startActivity(intent)
                }
            })
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun signInWithCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential).addOnCompleteListener { task ->
            setLoading(false)
            if (task.isSuccessful) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                status.text = "Login failed: ${task.exception?.message}"
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        sendOtp.isEnabled = !loading
    }
}
