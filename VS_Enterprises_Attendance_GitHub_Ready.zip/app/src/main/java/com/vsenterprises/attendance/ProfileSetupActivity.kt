package com.vsenterprises.attendance

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileSetupActivity : AppCompatActivity() {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_setup)

        val nameField = findViewById<EditText>(R.id.name)
        val empIdField = findViewById<EditText>(R.id.employeeId)
        val saveBtn = findViewById<Button>(R.id.save)
        val status = findViewById<TextView>(R.id.status)

        saveBtn.setOnClickListener {
            val name = nameField.text?.toString()?.trim().orEmpty()
            val empId = empIdField.text?.toString()?.trim().orEmpty()
            if (name.isEmpty() || empId.isEmpty()) {
                status.text = "Please fill in all fields."
                return@setOnClickListener
            }
            val user = auth.currentUser ?: return@setOnClickListener
            val data = hashMapOf(
                "name" to name,
                "employeeId" to empId,
                "mobile" to (user.phoneNumber ?: ""),
                "isAdmin" to false,
                "sharing" to false
            )
            saveBtn.isEnabled = false
            db.collection("employees").document(user.uid).set(data)
                .addOnSuccessListener {
                    startActivity(Intent(this, DashboardActivity::class.java))
                    finish()
                }
                .addOnFailureListener { e ->
                    saveBtn.isEnabled = true
                    status.text = "Failed to save: ${e.message}"
                }
        }
    }
}
