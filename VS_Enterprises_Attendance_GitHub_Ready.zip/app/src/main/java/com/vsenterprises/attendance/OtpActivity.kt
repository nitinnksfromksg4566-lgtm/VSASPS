package com.vsenterprises.attendance

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthProvider

class OtpActivity : AppCompatActivity() {

    private lateinit var otpField: EditText
    private lateinit var verifyBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var subtitle: TextView
    private val auth = FirebaseAuth.getInstance()
    private var verificationId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp)

        verificationId = intent.getStringExtra("verificationId").orEmpty()
        val phone = intent.getStringExtra("phone").orEmpty()

        otpField = findViewById(R.id.otp)
        verifyBtn = findViewById(R.id.verify)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        subtitle = findViewById(R.id.subtitle)
        subtitle.text = "Enter the 6-digit code sent to $phone"

        verifyBtn.setOnClickListener { attemptVerify() }
        findViewById<TextView>(R.id.resend).setOnClickListener {
            status.text = "Please go back and tap Send OTP again."
        }
    }

    private fun attemptVerify() {
        val code = otpField.text?.toString()?.trim().orEmpty()
        if (code.length != 6) {
            status.text = "Please enter the 6-digit OTP."
            return
        }
        setLoading(true)
        val credential = PhoneAuthProvider.getCredential(verificationId, code)
        auth.signInWithCredential(credential).addOnCompleteListener { task ->
            setLoading(false)
            if (task.isSuccessful) {
                startActivity(Intent(this, MainActivity::class.java))
                finishAffinity()
            } else {
                status.text = "Invalid OTP. ${task.exception?.message ?: ""}"
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        verifyBtn.isEnabled = !loading
    }
}
