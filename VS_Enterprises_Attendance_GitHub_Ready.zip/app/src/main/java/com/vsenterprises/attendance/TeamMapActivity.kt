package com.vsenterprises.attendance

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.firestore.FirebaseFirestore

class TeamMapActivity : AppCompatActivity(), OnMapReadyCallback {

    private val db = FirebaseFirestore.getInstance()
    private var map: GoogleMap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_team_map)
        val fragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        fragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        loadLiveLocations()
    }

    private fun loadLiveLocations() {
        db.collection("employees").whereEqualTo("sharing", true).get()
            .addOnSuccessListener { snapshot ->
                val gMap = map ?: return@addOnSuccessListener
                gMap.clear()
                val emptyLabel = findViewById<TextView>(R.id.emptyMap)

                if (snapshot.isEmpty) {
                    emptyLabel.visibility = View.VISIBLE
                    return@addOnSuccessListener
                }
                emptyLabel.visibility = View.GONE

                val boundsBuilder = LatLngBounds.Builder()
                var count = 0
                for (doc in snapshot.documents) {
                    val lat = doc.getDouble("liveLat") ?: continue
                    val lng = doc.getDouble("liveLng") ?: continue
                    val name = doc.getString("name") ?: "Employee"
                    val pos = LatLng(lat, lng)
                    gMap.addMarker(MarkerOptions().position(pos).title(name))
                    boundsBuilder.include(pos)
                    count++
                }
                if (count > 0) {
                    gMap.animateCamera(CameraUpdateFactory.newLatLngBounds(boundsBuilder.build(), 120))
                } else {
                    emptyLabel.visibility = View.VISIBLE
                }
            }
            .addOnFailureListener {
                findViewById<TextView>(R.id.emptyMap).apply {
                    visibility = View.VISIBLE
                    text = "Could not load map: ${it.message}"
                }
            }
    }
}
