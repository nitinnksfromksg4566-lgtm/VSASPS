package com.vsenterprises.attendance

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LocationService : Service() {
    private lateinit var fused: FusedLocationProviderClient
    private val db = FirebaseFirestore.getInstance()
    private val uid get() = FirebaseAuth.getInstance().currentUser?.uid
    private var endAt = 0L
    private var callback: LocationCallback? = null

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        startForeground(7, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        endAt = intent?.getLongExtra("endAt", 0L)
            ?: getSharedPreferences("duty", MODE_PRIVATE).getLong("endAt", 0L)
        requestUpdates()
        return START_STICKY
    }

    private fun notification(): Notification {
        val channel = "vs_location"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channel, "V S Enterprises Live Location",
            NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this, channel)
            .setContentTitle("V S Enterprises")
            .setContentText("Live location sharing is active until duty time ends")
            .setSmallIcon(R.drawable.vs_logo)
            .build()
    }

    private fun requestUpdates() {
        val user = uid
        if (user == null) {
            stopSelf()
            return
        }
        db.collection("employees").document(user).update("sharing", true)

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 15000L)
            .setMinUpdateIntervalMillis(10000L).build()

        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                if (endAt > 0 && System.currentTimeMillis() >= endAt) {
                    stopSharing()
                    return
                }
                val l = result.lastLocation ?: return
                db.collection("employees").document(user).update(
                    mapOf(
                        "liveLat" to l.latitude,
                        "liveLng" to l.longitude,
                        "liveUpdatedAt" to Timestamp.now(),
                        "sharing" to true
                    )
                )
            }
        }
        fused.requestLocationUpdates(request, callback as LocationCallback, mainLooper)
    }

    private fun stopSharing() {
        callback?.let { fused.removeLocationUpdates(it) }
        uid?.let {
            db.collection("employees").document(it).update("sharing", false)
        }
        getSharedPreferences("duty", MODE_PRIVATE).edit().putLong("endAt", 0L).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        callback?.let { fused.removeLocationUpdates(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
