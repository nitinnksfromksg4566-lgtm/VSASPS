package com.vsenterprises.attendance

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Calendar

class HistoryActivity : AppCompatActivity() {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val list = findViewById<RecyclerView>(R.id.list)
        val progress = findViewById<View>(R.id.progress)
        val empty = findViewById<TextView>(R.id.empty)
        val summary = findViewById<TextView>(R.id.summary)
        list.layoutManager = LinearLayoutManager(this)

        val user = auth.currentUser ?: return
        db.collection("attendance").whereEqualTo("uid", user.uid).get()
            .addOnSuccessListener { snapshot ->
                progress.visibility = View.GONE
                val records = snapshot.documents.map { doc ->
                    AttendanceRecord(
                        id = doc.id,
                        uid = doc.getString("uid") ?: "",
                        employeeName = doc.getString("employeeName") ?: "",
                        type = doc.getString("type") ?: "",
                        timestamp = doc.getTimestamp("timestamp")?.toDate()?.time ?: 0L,
                        dutyDurationHours = (doc.getLong("dutyDurationHours") ?: 0L).toInt()
                    )
                }.sortedByDescending { it.timestamp }

                if (records.isEmpty()) {
                    empty.visibility = View.VISIBLE
                } else {
                    list.adapter = HistoryAdapter(records)
                }
                summary.text = "This month: ${computeMonthlyHours(records)} hours logged"
            }
            .addOnFailureListener {
                progress.visibility = View.GONE
                empty.visibility = View.VISIBLE
                empty.text = "Could not load history: ${it.message}"
            }
    }

    private fun computeMonthlyHours(records: List<AttendanceRecord>): String {
        val cal = Calendar.getInstance()
        val currentMonth = cal.get(Calendar.MONTH)
        val currentYear = cal.get(Calendar.YEAR)

        val thisMonth = records.filter {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            c.get(Calendar.MONTH) == currentMonth && c.get(Calendar.YEAR) == currentYear
        }.sortedBy { it.timestamp }

        var totalMillis = 0L
        var pendingCheckIn: Long? = null
        for (r in thisMonth) {
            if (r.type == "checkin") {
                pendingCheckIn = r.timestamp
            } else if (r.type == "checkout" && pendingCheckIn != null) {
                totalMillis += r.timestamp - pendingCheckIn
                pendingCheckIn = null
            }
        }
        val hours = totalMillis / (1000 * 60 * 60)
        val minutes = (totalMillis / (1000 * 60)) % 60
        return "$hours hr $minutes min"
    }
}
