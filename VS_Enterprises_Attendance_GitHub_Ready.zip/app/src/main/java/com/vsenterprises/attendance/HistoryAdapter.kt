package com.vsenterprises.attendance

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Date

class HistoryAdapter(private val items: List<AttendanceRecord>) :
    RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    class ViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val type: TextView = itemView.findViewById(R.id.type)
        val date: TextView = itemView.findViewById(R.id.date)
        val time: TextView = itemView.findViewById(R.id.time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_attendance, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val d = Date(item.timestamp)
        holder.type.text = if (item.type == "checkin") "Check In" else "Check Out"
        holder.date.text = DateFormat.format("dd MMM yyyy", d).toString()
        holder.time.text = DateFormat.format("hh:mm a", d).toString()
    }

    override fun getItemCount() = items.size
}
